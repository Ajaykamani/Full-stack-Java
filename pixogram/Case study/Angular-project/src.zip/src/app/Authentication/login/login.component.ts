import { Component, OnInit } from '@angular/core';
import { UserAuthService } from 'src/app/services/authentication/user-auth.service';
import { Router } from '@angular/router';
import{FormGroup, FormControl, FormBuilder} from'@angular/forms';
import { UserRegistrationDetails } from 'src/app/model/user-registration.model';
import { UserRegistrationService } from 'src/app/services/user-registration.service';


@Component({
  selector: 'login',
  templateUrl: './login.component.html',
  styleUrls: ['./login.component.css']
})
export class LoginComponent implements OnInit {
  errorMessage: string;
  autherized: boolean;
  
  username:string;
  password:string;
  myFormGroup : FormGroup;
  details:Array<UserRegistrationDetails>;
   

  constructor(public auth : UserAuthService, public router : Router, formBuilder: FormBuilder,public userdetails :UserRegistrationService) { 
    
    this.autherized = true;

    this.myFormGroup=formBuilder.group({
      
      username:new FormControl(""),
      password: new FormControl(""),
        
     });
    
}


  checkUser(txtemail : HTMLInputElement, txtpassword : HTMLInputElement){
    
    if(this.auth.authenticate(txtemail.value, txtpassword.value)){
       console.log("hello");
        this.autherized = true;
        this.router.navigateByUrl('/media');
    }else{
        this.autherized = false;
        this.errorMessage = "Invalid Credentials!!!";
    }
  }
  login(){
    console.log("login method");
    this.username= this.myFormGroup.controls['username'].value;
    this.password=this.myFormGroup.controls['password'].value;
   console.log("Username : "+this.username+"\n"+"Password : "+this.password);
   }
  ngOnInit() {
  }

}