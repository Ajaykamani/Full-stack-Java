import { Component, OnInit } from '@angular/core';
import { FormGroup, FormBuilder, FormControl } from '@angular/forms';
import { UserAuthService } from 'src/app/services/authentication/user-auth.service';

@Component({
  selector: 'app-account-details',
  templateUrl: './account-details.component.html',
  styleUrls: ['./account-details.component.css']
})
export class AccountDetailsComponent implements OnInit {

  user:string;
  pass:string;
  repass:string;
  mail:string;
  myFormGroup : FormGroup;
  constructor(public auth : UserAuthService, formBuilder: FormBuilder) {
    console.log("in form bilder of re - reg");
    this.myFormGroup=formBuilder.group({
      "username":new FormControl(""),
      "password": new FormControl(""),
      "repassword":new FormControl(""),
      "email":new FormControl("")

    });

  }
  reReg(){
    console.log("Re-registration method");
    this.user= this.myFormGroup.controls['username'].value;
    this.pass=this.myFormGroup.controls['password'].value;
    this.repass=this.myFormGroup.controls['repassword'].value;
    this.mail=this.myFormGroup.controls['email'].value;
   console.log("Username : "+this.user+"\n"+"Password : "+this.pass+"\n"+"Re-password : "+this.repass+"\n"+"Email : "+this.mail);
  }

message():void{

  alert("Logged out!!!");
  this.auth.logout();
}
  ngOnInit() {
  }

}

