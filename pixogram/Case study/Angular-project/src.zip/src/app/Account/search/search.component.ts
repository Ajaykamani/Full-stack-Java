import { Component, OnInit } from '@angular/core';
import { FormGroup, FormBuilder, FormControl } from '@angular/forms';
import { UserAuthService } from 'src/app/services/authentication/user-auth.service';

@Component({
  selector: 'app-search',
  templateUrl: './search.component.html',
  styleUrls: ['./search.component.css']
})
export class SearchComponent implements OnInit {

  userSearch:string;
  myFormGroup:FormGroup;
  constructor(public auth : UserAuthService, formBuilder: FormBuilder) {
    console.log("in form bilder of search");
    this.myFormGroup=formBuilder.group({
      "search":new FormControl("")
    });

  }
  search(){
    console.log("Search method");
    this.userSearch= this.myFormGroup.controls['search'].value;
    console.log("you have searched for : "+this.userSearch);
  }
  message():void{
    
    alert("Logged out!!!");
    this.auth.logout();
  }
  

  ngOnInit() {
  }

}
