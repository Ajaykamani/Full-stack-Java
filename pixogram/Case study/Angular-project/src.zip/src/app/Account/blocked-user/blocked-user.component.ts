import { Component, OnInit } from '@angular/core';
import { UserAuthService } from 'src/app/services/authentication/user-auth.service';

@Component({
  selector: 'app-blocked-user',
  templateUrl: './blocked-user.component.html',
  styleUrls: ['./blocked-user.component.css']
})
export class BlockedUserComponent implements OnInit {

  constructor(public auth:UserAuthService) { }
  message():void{
    
    alert("Logged out!!!");
    this.auth.logout();
  }

  ngOnInit() {
  }

}
