import { Component, OnInit } from '@angular/core';
import { UserAuthService } from 'src/app/services/authentication/user-auth.service';

@Component({
  selector: 'app-activity-newsfeed',
  templateUrl: './activity-newsfeed.component.html',
  styleUrls: ['./activity-newsfeed.component.css']
})
export class ActivityNewsfeedComponent implements OnInit {

  constructor(public auth : UserAuthService) { }
  message():void{
    
    alert("Logged out!!!");
    this.auth.logout();
  }

  ngOnInit() {
  }

}
